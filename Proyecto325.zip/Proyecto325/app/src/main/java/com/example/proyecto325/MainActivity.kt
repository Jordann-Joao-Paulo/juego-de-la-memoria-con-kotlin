package com.example.proyecto325

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.graphics.Insets
import java.util.ArrayList
import java.util.Collections

class MainActivity : AppCompatActivity() {

    private lateinit var img0: ImageButton
    private lateinit var img1: ImageButton
    private lateinit var img2: ImageButton
    private lateinit var img3: ImageButton
    private lateinit var img4: ImageButton
    private lateinit var img5: ImageButton
    private lateinit var img6: ImageButton
    private lateinit var img7: ImageButton
    private lateinit var img8: ImageButton
    private lateinit var img9: ImageButton
    private lateinit var img10: ImageButton
    private lateinit var img11: ImageButton
    private lateinit var tablero: Array<ImageButton>
    private lateinit var reiniciar: Button
    private lateinit var salir: Button
    private var aciertos = 0
    private lateinit var imagenes: IntArray
    private var fondo = 0
    private lateinit var arrayDesordenado: ArrayList<Int>
    private var primero: ImageButton? = null
    private var numeroPrimero = 0
    private var numeroSegundo = 0
    private var bloqueo = false
    private val handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
        reiniciar = findViewById(R.id.button)
        salir = findViewById(R.id.button2)

    }

    private fun cargarTablero() {
        img0 = findViewById(R.id.imageButton3)
        img1 = findViewById(R.id.imageButton4)
        img2 = findViewById(R.id.imageButton5)
        img3 = findViewById(R.id.imageButton6)
        img4 = findViewById(R.id.imageButton7)
        img5 = findViewById(R.id.imageButton8)
        img6 = findViewById(R.id.imageButton9)
        img7 = findViewById(R.id.imageButton10)
        img8 = findViewById(R.id.imageButton11)
        img9 = findViewById(R.id.imageButton12)
        img10 = findViewById(R.id.imageButton13)
        img11 = findViewById(R.id.imageButton14)

        tablero = arrayOf(
            img0, img1, img2, img3, img4, img5, img6, img7, img8, img9, img10, img11
        )
    }

    private fun cargarBotones() {
        reiniciar = findViewById(R.id.button)
        salir = findViewById(R.id.button2)

        reiniciar.setOnClickListener { init() }

        salir.setOnClickListener { finish() }
    }

    private fun cargarImagenes() {
        imagenes = intArrayOf(
            R.drawable.memoalegria,
            R.drawable.memodesagrado,
            R.drawable.memofuria,
            R.drawable.memotristeza,
            R.drawable.memomiedo,
            R.drawable.memobingbong
        )
        fondo = R.drawable.cubreansiedad
    }

    private fun barajar(longitud: Int): ArrayList<Int> {
        val result = ArrayList<Int>()
        for (i in 0 until longitud * 2) {
            result.add(i % longitud)
        }
        Collections.shuffle(result)
        return result
    }

    private fun comprobar(i: Int, imgb: ImageButton) {
        if (primero == null) {
            primero = imgb
            primero!!.setImageResource(imagenes[arrayDesordenado[i]])
            primero!!.isEnabled = false
            numeroPrimero = arrayDesordenado[i]
        } else {
            bloqueo = true
            imgb.setImageResource(imagenes[arrayDesordenado[i]])
            imgb.isEnabled = false
            numeroSegundo = arrayDesordenado[i]
            if (numeroPrimero == numeroSegundo) {
                primero = null
                bloqueo = false
                aciertos++
                if (aciertos == imagenes.size) {
                    val toast = Toast.makeText(applicationContext, "GANASTE!!!", Toast.LENGTH_LONG)
                    toast.show()
                }
            } else {
                handler.postDelayed({
                    primero!!.setImageResource(fondo)
                    primero!!.isEnabled = true
                    imgb.setImageResource(fondo)
                    imgb.isEnabled = true
                    bloqueo = false
                    primero = null
                }, 1000)
            }
        }
    }

    private fun init() {
        cargarTablero()
        cargarBotones()
        cargarImagenes()
        arrayDesordenado = barajar(imagenes.size)
        for (i in tablero.indices) {
            tablero[i].setImageResource(imagenes[arrayDesordenado[i]])
        }
        handler.postDelayed({
            for (i in tablero.indices) {
                tablero[i].setImageResource(fondo)
            }
        }, 500)
        for (i in tablero.indices) {
            tablero[i].isEnabled = true
            tablero[i].setOnClickListener {
                if (!bloqueo) {
                    comprobar(i, tablero[i])
                }
            }
        }
    }

}